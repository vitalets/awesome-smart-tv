﻿using System;
namespace Application
{
    public class NewClass
    {
        public NewClass()
        {
        }
    }
}
