package com.pw.spider.regex;

public class CoverPageRegex {
	private String coverInfoRegex;

	private int coverImgUrlIndex;

	private int briefIndex;

	public String getCoverInfoRegex() {
		return coverInfoRegex;
	}

	public void setCoverInfoRegex(String coverInfoRegex) {
		this.coverInfoRegex = coverInfoRegex;
	}

	public int getCoverImgUrlIndex() {
		return coverImgUrlIndex;
	}

	public void setCoverImgUrlIndex(int coverImgUrlIndex) {
		this.coverImgUrlIndex = coverImgUrlIndex;
	}

	public int getBriefIndex() {
		return briefIndex;
	}

	public void setBriefIndex(int briefIndex) {
		this.briefIndex = briefIndex;
	}

}
