function [ output_args ] = SVMCompare( input_args )
%SVMCOMPARE Summary of this function goes here
%   Detailed explanation goes here


end

