function [ means, stdDevs ] = ScaleParameters( peaks, colNames )
%SCALEPARAMETERS Summary of this function goes here
%   Detailed explanation goes here
   
  
end

