# SVM_DNA_TunnelVision
Code to convert complicated tunneling or ionic signals from DNA nanopore reading into the corresponding DNA or analyte identities by the use of SVM.
