package de.danoeh.antennapod.core;

/**
 * Callbacks for Chromecast support on the core module
 */
public interface CastCallbacks {
}
