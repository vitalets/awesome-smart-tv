package de.danoeh.antennapod.core.util.flattr;

public interface FlattrThing {
	String getTitle();
	String getPaymentLink();
	FlattrStatus getFlattrStatus();
}
