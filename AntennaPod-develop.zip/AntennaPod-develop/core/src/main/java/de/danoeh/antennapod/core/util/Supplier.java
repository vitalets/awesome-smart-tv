package de.danoeh.antennapod.core.util;

public interface Supplier<T> {
    T get();
}
