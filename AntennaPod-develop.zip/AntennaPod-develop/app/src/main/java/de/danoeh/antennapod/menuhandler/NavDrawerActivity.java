package de.danoeh.antennapod.menuhandler;

/**
 * Defines useful methods for activities that have a navigation drawer
 */
public interface NavDrawerActivity {

    boolean isDrawerOpen();
}
