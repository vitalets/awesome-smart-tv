package de.danoeh.antennapod.config;

import de.danoeh.antennapod.core.CastCallbacks;

class CastCallbackImpl implements CastCallbacks {

}
