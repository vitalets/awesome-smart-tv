---
DELETE ME<br/>
You don't need to adhere to the template strictly. Feel free to leave out information you feel is not important or does not make sense.

If you are submitting a feature request, please read [this](https://github.com/AntennaPod/AntennaPod/blob/develop/CONTRIBUTING.md#how-to-submit-a-feature-request).
In particular, please not only tell us that you want something (*what*), but also make suggestions *how* it should be implemented.

---

**App version:** 1.x (from Google Play/F-Droid/Custom build)

**Android version**: 5.x [Please mention if you are using a custom rom!]

**Device model**:

**Expected behaviour**:

**Current behaviour**:

**First occured**: Version 1.x / about x days/weeks ago

**Steps to reproduce**:

1. This
1. Than that
1. Then

**Environment**: [Settings you have changed, e.g. Auto Download. "Unusual" devices you use, e.g. Bluetooth headphones. Do you still use Prestissimo?]

**Stacktrace/Logcat**: 
```
[if available]
```
