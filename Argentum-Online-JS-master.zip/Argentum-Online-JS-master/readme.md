Argentum Online JS
==================

# What is it?
This is the first revision of the Argentum Online JS (AOJS) Development SDK. It consists of several
tools and libraries packed on top of a PhaserJS installation to make AO development as easy and comfortable
as it was some time ago, with the added scalability and efficiency of JavaScript and modern game design.