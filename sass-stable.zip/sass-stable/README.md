## The Ruby Sass Repository Has Moved!

The Ruby Sass repository has moved from `https://github.com/sass/sass` to
[`https://github.com/sass/ruby-sass`][ruby-sass]. Please update your Git URLs to
point to the new repository. After 26 March 2019, this repository's history will
be deleted.

[ruby-sass]: https://github.com/sass/ruby-sass

Issues with the Ruby Sass implementation should be filed against
[the new repository][ruby-sass]. This repository will continue to track issues
related to Sass language design as a whole.
