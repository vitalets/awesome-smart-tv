<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockmanufacturer}touchmenot1.0.3>blockmanufacturer_2377be3c2ad9b435ba277a73f0f1ca76'] = 'Fabricants';
$_MODULE['<{blockmanufacturer}touchmenot1.0.3>blockmanufacturer_49fa2426b7903b3d4c89e2c1874d9346'] = 'Plus d\'informations sur';
$_MODULE['<{blockmanufacturer}touchmenot1.0.3>blockmanufacturer_bf24faeb13210b5a703f3ccef792b000'] = 'Tous les fabricants';
$_MODULE['<{blockmanufacturer}touchmenot1.0.3>blockmanufacturer_1c407c118b89fa6feaae6b0af5fc0970'] = 'Aucun autre fabricant de';
