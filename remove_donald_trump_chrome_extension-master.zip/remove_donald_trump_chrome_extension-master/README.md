# Remove Donald Trump from Facebook Feed
Chrome Extension that removes all Facebook posts that mention Donald Trump

Free on Chrome Store: https://chrome.google.com/webstore/detail/remove-donald-trump-from/hhokbihnhhfghkbmihlgfcoafhkghdej
