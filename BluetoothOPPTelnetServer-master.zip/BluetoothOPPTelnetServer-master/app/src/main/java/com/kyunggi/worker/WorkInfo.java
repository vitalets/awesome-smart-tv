package com.kyunggi.worker;

public class WorkInfo
{
	int minimumAuthority;
	String name;
	
}
