package com.kyunggi.worker.ExternalProgram;

public interface IStringSender
{
	public void SendString(String s);
	public void SendString(String [] sarr);
}
