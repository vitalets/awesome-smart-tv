#!/bin/bash

convert -delay 30 $1/*.png movie.mpg
