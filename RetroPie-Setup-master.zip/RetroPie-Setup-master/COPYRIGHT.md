The RetroPie Project
Copyright (C) 2012-2017 by the following:

If you have contributed to this project then you deserve to be on this
list. Contact us (see: AUTHORS) and we'll add you.

* Florian Müller "petrockblog"
* Jools Wills "joolswills"
* Peter Mahlknecht
* Aloshi
* Martin Modahl
* marqs
* Juan Pablo Zapata, jpzapa
* Xevin
* James Le Cuirot
* Ewan Meadows
* Adam "adskiremote"
* Hyperspin
* Claudio Cesar Sanchez Tejeda,
* cdu13a
* Christian Bryn
* Adam Smith
* Adrian Moisey
* Sergej Tatarincev
* "HerbFargus"
* Stefan "gizmo98"

For most recent list see also https://github.com/RetroPie/RetroPie-Setup/graphs/contributors
