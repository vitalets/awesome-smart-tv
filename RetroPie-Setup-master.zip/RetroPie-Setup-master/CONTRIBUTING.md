# How to contribute

## Support Requests vs Bug reporting

Please use the github for bug reports only. For help / support in using RetroPie and the emulators
it ships with, please use the RetroPie forum - https://retropie.org.uk/forum/

## Pull Requests

Contributions to the project are welcome - please check out our Styleguide before submitting changes
https://github.com/RetroPie/RetroPie-Setup/wiki/Shell-Style-Guide