/**
 * This file is provided by Facebook for testing and evaluation purposes
 * only. Facebook reserves all rights not expressly granted.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * FACEBOOK BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
 * AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

var Chat = require('../modules/chat')
var React = require('react')
var NuclearMixin = require('nuclear-js-react-addons/nuclearMixin')

var ENTER_KEY_CODE = 13

// Difference with classic suggested architecture:
// use the nuclear react mixin to have access to the
// reactor in the context, that you can then use to
// pass as first arguments of your actions

var MessageComposer = React.createClass({
  mixins: [NuclearMixin],

  propTypes: {
    threadID: React.PropTypes.string.isRequired,
  },

  getInitialState: function() {
    return {text: ''}
  },

  render: function() {
    return (
      <textarea
        className="message-composer"
        name="message"
        value={this.state.text}
        onChange={this._onChange}
        onKeyDown={this._onKeyDown}
      />
    )
  },

  _onChange: function(event, value) {
    this.setState({text: event.target.value})
  },

  _onKeyDown: function(event) {
    if (event.keyCode === ENTER_KEY_CODE) {
      event.preventDefault()
      var text = this.state.text.trim()
      if (text) {
        Chat.actions.createMessage(this.context.reactor, text, this.props.threadID)
      }
      this.setState({text: ''})
    }
  },
})

module.exports = MessageComposer
