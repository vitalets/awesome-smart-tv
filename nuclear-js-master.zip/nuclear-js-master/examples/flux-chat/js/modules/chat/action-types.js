var keyMirror = require('keymirror')

module.exports = keyMirror({
  ADD_MESSAGE: null,
  CLICK_THREAD: null,
})
