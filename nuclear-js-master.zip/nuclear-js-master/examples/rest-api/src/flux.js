var Nuclear = require('nuclear-js')

module.exports = new Nuclear.Reactor({
  debug: true,
})
