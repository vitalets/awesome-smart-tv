var keyMirror = require('keymirror')

module.exports = keyMirror({
  REGISTER_FORM: null,
  SET_FORM_VALUE: null,
  UNREGISTER_FORM: null,
})
