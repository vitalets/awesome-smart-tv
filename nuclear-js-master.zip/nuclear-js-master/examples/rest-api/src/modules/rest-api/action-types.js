var keyMirror = require('keymirror')

module.exports = keyMirror({
  API_FETCH_SUCCESS: null,
  API_FETCH_START: null,
  API_FETCH_FAIL: null,

  API_SAVE_SUCCESS: null,
  API_SAVE_START: null,
  API_SAVE_FAIL: null,

  API_DELETE_SUCCESS: null,
  API_DELETE_START: null,
  API_DELETE_FAIL: null,
})
