var keyMirror = require('keymirror')

module.exports = keyMirror({
  SET_CURRENTLY_EDITING_USER_ID: null,
})
