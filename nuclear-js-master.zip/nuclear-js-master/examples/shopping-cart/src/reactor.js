import { Reactor } from 'nuclear-js'

const reactor = new Reactor({ debug: true })

export default reactor
