export function increment(reactor) {
  reactor.dispatch('increment')
}

export function decrement(reactor) {
  reactor.dispatch('decrement')
}
