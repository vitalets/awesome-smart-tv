module.exports = {
  options: {
    debug: true,
    coverageDir: 'coverage',
  },
}
