module.exports = {
  all: {
    'pre-commit': 'eslint',
  },
}
