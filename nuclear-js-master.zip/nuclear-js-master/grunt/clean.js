module.exports = {
  coverage: ['coverage/**'],
  dist: ['dist/**'],
}
