TODO for `1.3.0`
===

 - [x] add documentation for all new reactor options
 - [x] add tests for all new reactor options
 - [x] link the nuclear-js package from the hot reloadable example
 - [ ] link `0.3.0` of `nuclear-js-react-addons` in hot reloadable example
 - [ ] add `nuclear-js-react-addons` link in example and documentation
 - [ ] publish doc site

