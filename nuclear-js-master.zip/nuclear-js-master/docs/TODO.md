# Documentation site TODO List

- [x] links to docs, API, github
- [x] build pipeline for docs from MD files
- [x] navbar working in mobile
- [x] async actions doc page
- [ ] api documentation generation using code source
- [ ] scaffold design patterns/examples area
- [ ] mobile side navbar
- [ ] build pipeline for examples, create example component, possibly with code editing
- [x] add active state to Docs side bar. (currently doesn't show which tab is active/selected)
