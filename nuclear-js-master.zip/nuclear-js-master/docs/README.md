# NuclearJS Docs

Documentation site statically generated using `React` + `NuclearJS`.

### For development

```sh
grunt dev
```

### To deploy to gh-pages

```sh
grunt publish
```
