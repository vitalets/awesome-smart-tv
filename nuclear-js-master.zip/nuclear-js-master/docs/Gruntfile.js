module.exports = function(grunt) {
  require('load-grunt-config')(grunt)

  grunt.loadNpmTasks('grunt-gh-pages')
}
