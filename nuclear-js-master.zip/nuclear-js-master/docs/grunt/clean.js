module.exports = {
  compiled: 'compiled/**',
  dist: 'dist/**',
  'gh-pages': ['.grunt/grunt-gh-pages'],
}
