module.exports = {
  'build-site': {
    files: 'src/**',
    tasks: ['build-site'],
  },
}
