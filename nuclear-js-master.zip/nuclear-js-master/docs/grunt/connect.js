module.exports = {
  dev: {
    options: {
      base: 'dist/',
      port: 4000,
    },
  },
}
