module.exports = {
  options: {
    base: 'dist',
    repo: 'git@github.com:optimizely/nuclear-js.git',
  },
  src: ['**'],
}

