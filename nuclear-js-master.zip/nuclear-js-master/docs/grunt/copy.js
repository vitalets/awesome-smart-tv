module.exports = {
  assets: {
    src: 'assets/**',
    expand: true,
    dest: 'dist/',
  },
}
