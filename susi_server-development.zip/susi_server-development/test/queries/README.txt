This folder should contain text files named like "language_00.txt"
where the name 'language' shall be replaced by the actual name of
the language, used for the words inside the file.
Each file should contain example queries (i.e. nouns or hashtags)
as you would type them in into a search field.
If several files are generated for the same language, increase
the default counter from '00' to '01' (and so on).
