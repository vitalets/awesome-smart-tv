# SUSI.AI

> “I’m a young, naive being, sometimes unsure about my own statements, sometimes quirky and maybe rough, provocative in cases where the person who talks to me is provocative as well. In other cases I’m a friendly and a bit cute being”, says Susi.



**You can chat with our dear *Susi* by asking ..**

* [General](#general)
* [Twitter/Loklak](#twitterloklak)
* [RSS Feeds](#rss-feeds)
* [Events](#events)
* [Wordpress](#wordpress)
* [Github](#github)
* [Instagram](#instagram)
* [Date/Time](#datetime)
* [Wikipedia](#wikipedia)
* [Quora](#quora)
* 
###General

- `<random>` Hello `<random>`. <br>
_example:_ Hello Susi, How are you ?

- `<random>` I feel `<your-feeling>`.<br>
_example:_ Hi, I feel super happy today !

- `<random>` Sorry `<random>`<br>
_example:_ I am sorry Susi.

- `<random>` Am I famous `<random>`<br>
_example:_ Tell me, am I famous Susi ?

- `<random>` I am `<random>`<br>
_example:_ I am Bond, James Bond.

- `<random>` You `<random>` <br>
_example:_  Hey Susi, You are awesome !

- What are your interests ?

- What `<random>` you like ?

- Where did you come from ?

- Where do you live ?

- Would like to know more about you !

- How was your day ?

- I need some help with `<random>` *OR* I need some help *OR* I need some help with this problem *OR* I'm in need of help `<random>`

- What is `<random>` ? *OR* What does `<random>` mean ? *OR* (Please) describe `<random>` *OR* (Please) explain `<random>`<br>
_example:_ Please explain insomnia.

***
###Twitter/Loklak

- Who tweeted most about `<query-term>` ? *OR* The top tweeter about `<query-term>`<br>
_example:_  Who tweeted most about pokemongo ?

- How many times was `<query-term>` tweeted in the last 24 hours ?<br>
_example:_  How many times was pokemongo tweeted in the last 24 hours ?

- `<random>` tweets did `<query-username>` post in `<query-month>` ?<br>
_example:_  How many tweets did melaniatrump post in May 2016 ?

- `<random>` tweets did `<query-username>` post at `<query-time>` ?<br>
_example:_  How many tweets did melaniatrump post at 6 PM ?

- `<random>` tweets did `<query-username>` post on `<query-day>`s ?<br>
_example:_  How many tweets did melaniatrump post on Saturdays ?

- `<random>` the `<query-frequency> (yearwise / hourwise / daywise)` tweet frequency chart of `<query-username>` ?<br>
_example:_  Show me the yearwise tweet frequency chart of melaniatrump 

- `<random>` did `<query-username>` post a `<query-tweet-type>` ?<br>
_example:_  How many times did melaniatrump post a video ?

- `<random>` likes does `<query-username>` have `<random>` ?<br>
_example:_  How many likes does melaniatrump have in all ?

- `<random>` maximum `<random>` likes that `<query-username>` got ?<br>
_example:_  What is the maximum number of likes that melaniatrump got ?

- `<random>` average `<random>` likes that `<query-username>` gets ?<br>
_example:_  What is the average number of likes that melaniatrump gets ?

- `<random>` `<query-username>` get `<query-number>` likes ?<br>
_example:_  How many times did melaniatrump get 0 likes ?

- `<random>` likes frequency chart `<random>` `<query-username>`<br>
_example:_  Show me the likes frequency chart of melaniatrump

- `<random>` retweets does `<query-username>` have `<random>` ?<br>
_example:_  How many retweets does melaniatrump have in all ?

- `<random>` maximum `<random>` retweets that `<query-username>` got ?<br>
_example:_  What is the maximum number of retweets that melaniatrump got ?

- `<random>` average `<random>` retweets that `<query-username>` gets ?<br>
_example:_  What is the average number of retweets that melaniatrump gets ?

- `<random>` `<query-username>` get `<query-number>` retweets ?<br>
_example:_  How many times did melaniatrump get 0 retweets ?

- `<random>` retweet frequency chart `<random>` `<query-username>`<br>
_example:_  Show me the retweet frequency chart of melaniatrump 

- `<random>` hashtags has `<query-username>` used `<random>` ?<br>
_example:_  How many hashtags has melaniatrump used in all ?

- `<random>` maximum `<random>` hashtags that `<query-username>` used ?<br>
_example:_  What is the maximum number of hastags that melaniatrump used ?

- `<random>` average `<random>` hashtags that `<query-username>` uses ?<br>
_example:_  What is the average number of hashtags that melaniatrump uses ?

- `<random>` `<query-username>` use `<query-number>` hashtags ?<br>
_example:_  How many times did melaniatrump use 20 hashtags ?

- `<random>` hashtag frequency chart `<random>` `<query-username>`<br>
_example:_  Show me the hashtag frequency chart of melaniatrump

- `<random>` `<query-username>` write in `<query-language>` ?<br>
_example:_  How many tweets did melaniatrump write in English ?

- `<random>` language analysis chart `<random>` `<query-username>`<br>
_example:_  Show me the language analysis chart of melaniatrump

- `<random>` sentiment analysis chart `<random>` `<query-username>`<br>
_example:_  Show me the sentiment analysis chart of melaniatrump

***
###RSS Feeds

- `<random>` read `<random>` RSS `<link-of-RSS-feeds>`<br>
_example:_ Susi, Please read the RSS feed from https://news.ycombinator.com/rss

- How many mentions are on reddit about `<query-term>` ? <br>
_example:_ How many mentions are on reddit about Loklak ?

- What are the reddit articles about `<query-term>` ? <br>
_example:_ What are the reddit articles about Loklak ?

***
###Events

- `<random>` about `<random>` event `<event-name-as-on-eventbrite.com>`<br>
_example:_ Susi, Tell me more about the event billets-europeade-2016-concert-de-musique-vocale-25592599153 ?

- `<random>`updates `<random>` event `<event-name-as-on-eventbrite.com>`<br>
_example:_ Susi, Where can I get updates of the event billets-europeade-2016-concert-de-musique-vocale-25592599153 ?

- `<random>` organizing `<random>` event `<event-name-as-on-eventbrite.com>`<br>
_example:_ Susi, who is organizing the event billets-europeade-2016-concert-de-musique-vocale-25592599153 ?

- `<random>` where `<random>` event `<event-name-as-on-eventbrite.com>` `<random>` held `<random>`<br>
_example:_ Susi, where is the event billets-europeade-2016-concert-de-musique-vocale-25592599153 being held ?

- `<random>`tickets `<random>`event `<event-name-as-on-eventbrite.com>` <br>
_example:_ Where can I buy tickets for the event billets-europeade-2016-concert-de-musique-vocale-25592599153 ?

***
###Wordpress

- `<random>` display `<random>` blog `<link-to-wordpress-blog>`<br>
_example:_ Display articles from the blog http://ishothim.com/

- `<random>` read `<random>` wordpress `<random>` from `<link-to-wordpress-blog>`<br>
_example:_ Susi, Read wordpress blogs from http://ishothim.com/

- `<random>` view `<random>` wordpress `<random>` from `<link-to-wordpress-blog>` <br>
_example:_ Susi, Can I view the articles from wordpress blog from http://ishothim.com/

***
###Github

- `<random>` find `<username-as-on-Github>` on `<random>` github `<random>` <br>
_example:_ Can you find mariobehling on Github and give me information ?

- `<random>` github `<random>` about `<username-as-on-Github>`<br>
_example:_ Give me more information from Github about mariobehling

- `<random>` read `<username-as-on-Github>` github `<random>`<br>
_example:_ Read mariobehling Github profile.

- `<random>` github `<random>` profile `<random>` of `<username-as-on-Github>`<br>
_example:_ Susi, What are the github profile stats of mariobehling

- `<random>` github `<random>` of `<username-as-on-Github>`<br>
_example:_ Susi, View/Read the Github profile of mariobehling

***
###Instagram

- `<random>` find `<username-as-on-Instagram>` on `<random>` Instagram `<random>` <br>
_example:_ Can you find justinpjtrudeau on Instagram and give me information ?

- `<random>` Instagram `<random>` about `<username-as-on-Instagram>`<br>
_example:_ Give me more information from Instagram about justinpjtrudeau

- `<random>` read `<username-as-on-Instagram>` Instagram `<random>`<br>
_example:_ Read justinpjtrudeau Instagram profile.

- `<random>` Instagram `<random>` profile `<random>` of `<username-as-on-Instagram>`<br>
_example:_ Susi, What are the Instagram profile stats of justinpjtrudeau

- `<random>` Instagram `<random>` of `<username-as-on-Instagram>`<br>
_example:_ Susi, View/Read the Instagram profile of justinpjtrudeau

***
###Date/Time

- `<random>` time `<random>` at `<location-name>`<br>
_example:_ Susi, what is the current time at Singapore ?

***

###Wikipedia

- `<random>` wikipedia articles `<random>` location `<location-name>`<br>
_example:_ Show me the wikipedia articles tagged with location Berlin.

***

###Quora

- `<random>` find `<username-as-on-Quora>` on `<random>` Quora `<random>` <br>
_example:_ Can you find Mark-Zuckerberg on Quora and give me information ?

- `<random>` Quora `<random>` about `<username-as-on-Quora>`<br>
_example:_ Give me more information from Quora about Mark-Zuckerberg

- `<random>` read `<username-as-on-Quora>` Quora `<random>`<br>
_example:_ Read Mark-Zuckerberg Quora profile.

- `<random>` Quora `<random>` profile `<random>` of `<username-as-on-Quora>`<br>
_example:_ Susi, What are the Quora profile stats of Mark-Zuckerberg

- `<random>` Quora `<random>` of `<username-as-on-Quora>`<br>
_example:_ Susi, View/Read the Quora profile of Mark-Zuckerberg


