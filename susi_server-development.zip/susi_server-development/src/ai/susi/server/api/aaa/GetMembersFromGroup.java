package ai.susi.server.api.aaa;

/**
 * Created by chetankaushik on 14/06/17.
 */
public class GetMembersFromGroup {
}
