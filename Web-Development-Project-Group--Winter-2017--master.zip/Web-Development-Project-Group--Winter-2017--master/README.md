# Web Development Project Group (Winter 2017)
We dem boyz.

## Syllabus
Week 1 - Basic HTML
 * [Exercise 1 - Basic HTML](https://github.com/UCSB-dataScience-ProjectGroup/Web-Development-Project-Group--Winter-2017-/tree/master/Exercise%201%20-%20Basic%20HTML)
 * Project: HTML + CSS Resume
