## heres a thing i wrote while my parents were watching the sopranos
# but i had already seen the episode they were watching so i was just
## kind of dicking around on my laptop and i started looking at the 
game clip viewer on xbox.com and i wrote this script that would download
## random clips that come from people saying "xbox, record that" and i
# watched it for a while and it was kind of hypnotizing and relaxing but
## then it would get really weird because you'd see some really brutal kill
in like mortal kombat or something or youd see someones body get all
## glitched up ina s ports game it was kind of off putting but itll all be
over in 30 seconds because thats how long the clips are so u just gotta
# soldier through it and get to the next one i know u can do it




## so anyway if u want to use this u'll have to put your own auth into it in a file called auth.txt that just goes in the root directory
# to get the auth just look at ur requests as u go to your profile on xbox.com and look for requests to eds-origin.xboxlive.com and copy the value for the authorization header
it should look like "XBL3.0 x=" and then a bunch of other shit but yea just copy it and put it in auth.txt and u'll be cool

## also the title_ids.txt is way out of date so just get a good list of title ids
# titles ids in the title_ids.txt are in dec not hex so if u got em in hex ur gonna have to convert them or just like
update the code to parse either idk do what u want
## but if u just wanna update the title_ids.txt to have more games id appreciate it and id like a pull request
# maybe i should open an issue for that

idk but ur welcome alex