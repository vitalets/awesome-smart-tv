### Classification (Please choose *one* option):

* [x] Crash/Hang/Data loss
* [ ] WebUI/Usability
* [ ] Serious bug
* [ ] Ordinary bug
* [ ] Feature
* [ ] Enhancement

### Reproducibility (Please choose *one* option):

* [X] Always
* [ ] Sometimes
* [ ] Rarely
* [ ] Unable
* [ ] I didn’t try
* [ ] Not applicable

### Rspamd version:

### Operation system, CPU:

### Description (Please provide a descriptive summary of the issue):

### Compile errors (if any):

### Relevant logs (see details [here](https://rspamd.com/doc/faq.html#how-to-debug-some-module-in-rspamd)):

### Expected results:

### Actual results:

### Debugging information (see details [here](https://rspamd.com/doc/faq.html#how-to-figure-out-why-rspamd-process-crashed)):

### Configuration (e.g. `rspamadm configdump module`):

### Additional information:
