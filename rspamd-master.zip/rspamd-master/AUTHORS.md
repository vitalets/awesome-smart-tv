# Project Authors and Contributors

Rspamd was created by [Vsevolod Stakhov](https://github.com/vstakov) while working in [Rambler Mail](https://mail.rambler.ru/)

## Authors

* [Vsevolod Stakhov](https://github.com/vstakov)

## Developers

* [Mikhail Galanin](https://github.com/negram)
* [Alexander Moisseev](https://github.com/moisseev)

## Alumni Developers

* [Andrew Lewis](https://github.com/fatalbanana)

## Significant contributors

* [Steve Freegard](https://github.com/smfreegard)
* [Alexey Savelyev](https://github.com/AlexeySa)
* [Anna Stakhova](https://github.com/AnnaStakhova)

<https://github.com/rspamd/rspamd/graphs/contributors>

## Special thanks to

* [Mimecast](https://mimecast.com)
* [Rambler Mail](https://mail.rambler.ru/)
* [Locaweb](https://locaweb.com.br)