
-- https://github.com/torch/torch7/issues/525

local dl = {}
return dl