# Rspamd Dependency Info

- aho-corasick      Version: ?      License: LGPL-3.0               Patched: YES
- cdb               Version: 1.1.0  License: Public Domain / CC0    Patched: NO
- hiredis           Version: 0.13.3 License: BSD-3-Clause           Patched: YES
- lc-btrie          Version: ?      License: BSD-3-Clause           Patched: YES
- libottery         Version: ?      License: Public Domain / CC0    Patched: YES
- librdns           Version: ?      License: BSD-2-Clause           Patched: ?
- libucl            Version: ?      License: BSD-2-Clause           Patched: ?
- linenoise         Version: 1.0    License: BSD-2-Clause           Patched: ?
- lpeg:             Version: 1.0    License: MIT                    Patched: NO
- lua-fun           Version: ?      License: MIT                    Patched: NO
- lua-tableshape    Version: ae67256 License: MIT                   Patched: NO
- moses             Version: ?      License: MIT                    Patched: ?
- mumhash           Version: ?      License: MIT                    Patched: ?
- ngx-http-parser   Version: 2.2.0  License: MIT                    Patched: ?
- perl-Mozilla-PublicSuffix
                    Version: ?      License: MIT                    Patched: ?
- snowball          Version: ?      License: BSD-3-Clause           Patched: ?
- t1ha              Version: ?      License: Zlib                   Patched: ?
- torch             Version: ?      License: ASL-2.0 v BSD-3-Clause Patched: YES
- uthash            Version: 1.9.8  License: BSD                    Patched: ?
- xxhash            Version: ?      License: BSD                    Patched: ?
- zstd              Version: 1.3.1  License: BSD                    Patched: NO
