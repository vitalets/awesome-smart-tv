'use strict';

import menuFactory from '../menuFactory';

const styles = {};

export default menuFactory(styles);
