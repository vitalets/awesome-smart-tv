package test;

public class Main {
  public static void main(String[] args) throws Exception {
    for (String s: args) {
      System.out.println(s);
    }
  }
}
