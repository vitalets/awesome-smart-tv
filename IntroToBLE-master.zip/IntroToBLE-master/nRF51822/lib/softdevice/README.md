Download the Nordic SoftDevice and place it in this folder.

For example, SD version 6.0.0 should be placed in `/lib/softdevice/s110_nRF51822_6.0.0` which will give the following path to the softdevice .hex file: `/lib/softdevice/s110_nRF51822_6.0.0/s110_nRF51822_6.0.0_softdevice.hex`

Be sure to include the entire soft device package in this folder since the header files in the package are also required.
