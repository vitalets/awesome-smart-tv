Download the Nordic SDK and place it in this folder, making sure there are no spaces in the folder name:

```
  [projfolder]/lib/sdk/nRF51_SDK_v5.2.0.39364
```

**NOTE:** To download the 5.2.0 SDK files you must click on the `nRF518-SDK - nRF51 SDK Installer` entry on your MyPages account, specifically the version number to the right-hand side.  This will give you a list of all available SDK versions.  Download the **5.2.0** version, install it in your development machine, and then move the files to the folder listed above.
