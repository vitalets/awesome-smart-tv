# iBeacon firmware for BLE112#

This is the BLE112 firmware source code for a iOS 7 iBeacon compatible device.
You can find more information here:

Jens Willy's very informative blog
http://jenswilly.dk/tag/ibeacon/

and also here on Bluegiga's site:

Mikko Savolainen's Apple iBeacon example in the Bluegiga Knowledgebase (a login may be required)
https://bluegiga.zendesk.com/entries/29990857-Apple-iBeacon-example