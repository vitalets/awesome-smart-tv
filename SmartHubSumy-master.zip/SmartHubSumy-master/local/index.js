module.exports = Local = (arg) => {

  var vocabulary = {
    'question': {
      'add_user': ['Я не бачив тебе раніше, познайомимось?', 'Я тебе не знаю давай знайомитись'],
      'name_user': 'Як тебе звуть?(ПІБ)',
      'age': ['Скільки тобі років?','Вік:'],
      'num_phone': ['Твій телефон:', 'Мобільний:'],
      'mail': 'І твоя електронна адреса:'
    },
    'speech': {
      'events': ['Щоб вивести актуальні заходи використовуй /events', 'Використовуй /events щоб отримати список актуальних заходів'],
      'thank': ['Дякую, тепер можеш обрати захід', 'Обирай захід'],
      'yes': ['Так', 'OK'],
      'no': ['Ні', 'Неа'],
      'see_you': ['Чекаємо тебе на заході', 'Будемо чекати'],
      'dev': ['Ведеться розробка', 'Буде доступно пізніше']
    },
    'admin': {
      'workPost': 'Робота над постами',
      'addPost': 'Робота над постами',
      'delPost': 'Робота над постами',
      'setHeader': 'Вкажи назву заходу',
      'setDescription': 'Опис заходу',
      'setTime': 'Вкажи час проведення, наприклад: 01.01 13:00',
      'setTag': 'Вкажи тег, наприклад: #SmartHub',
      'setPhoto': 'Додай фото',
      'published': 'Пост опублікований',
      'notPublished': 'На жаль :('
    }
  }

  var arg = arg.split('::'),
    word = ''

  for (var i = 0; i < arg.length; i++) {

    let step = vocabulary[arg[i]]

    if (typeof step === 'object') vocabulary = step
    if (typeof step === 'string') return step
    if (step instanceof Array) return step[Math.floor(Math.random() * step.length)];

  }

}
