const User = require('./model')
const UI = require('./ui')
const Account = require('./account')
const Post = require('./post')
const Local = require('./local')
const ValidOfVal = require('./validOfVal')
const Report = require('./report')

const ip = require('public-ip')

const TeleBot = require('telebot')
const bot = new TeleBot('483981826:AAHwPdhTQ5uE6WByExMGcJs_40wjHyXTcF8')

const code_admin = '616263'

bot.on('callbackQuery', msg => {

  Account.check(msg, (result, admin) => {

    if (msg.data == 'NewUser' && !result) {
      Account.create(msg)
      bot.sendMessage(msg.from.id, Local('question::name_user'))
    }

    if (msg.data == 'Member') {
      bot.sendMessage(msg.from.id, Local('speech::see_you'))
    }

    if (msg.data == 'AddPost') {
      Post.create(msg)
      bot.sendMessage(msg.from.id, Local('admin::addPost'))
    }

    if (msg.data == 'DelPost') {
      Post.create(msg)
      bot.sendMessage(msg.from.id, Local('admin::delPost'))
    }

  })

  return bot.answerCallbackQuery(msg.id, `Inline button callback: ${ msg.data }`, true)

})

bot.on(['text'], msg => {

  Account.check(msg, (user, admin) => {

    if (msg.text == '/getIP' + code_admin) {

      ip.v4().then(ip => {
        msg.reply.text(ip)
      })

    }

    if (user) {

      if (admin) {

        if (msg.text == '/getIP' + code_admin) {

          ip.v4().then(ip => {
            msg.reply.text(ip + 'admin')
          })

        }

        if (msg.text == '/workPost') {

          let replyMarkup = UI.inline_btn(bot, 'workPost')
          bot.sendMessage(msg.from.id, Local('admin::workPost'), {
            replyMarkup
          })
        }

        if (msg.text == '/report') {
          Report(data => {
            bot.sendDocument(msg.from.id, data)
          })

        }

      }

      if (msg.text == '/start') {
        bot.sendMessage(msg.from.id, Local('speech::events'))
      }

      if (msg.text == '/events') {


        Post.show(post => {

          //let caption = post.caption

          bot.sendPhoto(msg.from.id, post.img).then(re => {
            affixText(msg.from.id, re.result.message_id, post)
          })

        })


      }

      if (ValidOfVal(msg, 'name')) {
        Account.update(msg, 'name', 'text', () => {
          bot.sendMessage(msg.from.id, Local('question::age'))
        })
      } else if (ValidOfVal(msg, 'age')) {
        Account.update(msg, 'age', 'text', () => {
          bot.sendMessage(msg.from.id, Local('question::num_phone'))
        })
      } else if (ValidOfVal(msg, 'num_phone')) {
        Account.update(msg, 'num_phone', 'text', () => {
          bot.sendMessage(msg.from.id, Local('question::mail'))
        })
      } else if (ValidOfVal(msg, 'email')) {
        Account.update(msg, 'mail', 'text', () => {
          bot.sendMessage(msg.from.id, Local('speech::thank'))
        })
      }

    } else {

      if (msg.text == '/start') {
        let replyMarkup = UI.inline_btn(bot, 'reg')
        bot.sendMessage(msg.from.id, Local('question::add_user'), {
          replyMarkup
        })
      }

    }

  })

})

affixText = (chatId, messageId, post) => {
  bot.sendMessage(chatId, post.caption, { replyToMessage: messageId })
}

bot.start()
