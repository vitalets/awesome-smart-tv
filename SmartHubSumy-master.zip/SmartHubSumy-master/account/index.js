const mongoose = require('mongoose')
const collection = 'SmartHubSumyBot'

const model = require('../model')
const User = model.User

mongoose.connect('mongodb://localhost/' + collection, {
  useMongoClient: true
})

mongoose.Promise = global.Promise

check = (msg, callback) => {

  if (msg.from.is_bot) return

  User.findOne({
    chat_id: msg.from.id
  }, function(err, user) {

    let userList = JSON.stringify(user)

    if (userList.length && user.admin) callback(true, true)
    if (userList.length && !user.admin) callback(true, false)
    if (!userList.length) callback(false, false)

  })

}

check_admin = (msg, callback) => {

  User.findOne({
    chat_id: msg.from.id
  }, function(err, user) {

    callback(user.admin);

  })

}

create = (msg) => {

  User.create({
    chat_id: msg.from.id,
    username: msg.from.username,
    admin: false,
    meta: {
      name: null,
      age: null,
      num_phone: null,
      mail: null,
      organisation: null,
      position: null
    },
    lang: msg.from.language_code,
    is_bot: msg.from.is_bot,
    stage: 'basic'
  })

}

update = (msg, field, type, callback) => {

  User.findOne({
    chat_id: msg.from.id
  }, function(err, user) {
    user.meta[field] = msg[type]
    user.save()
  })

  callback(msg.from.id)

}

module.exports.check = check
module.exports.check_admin = check_admin
module.exports.create = create
module.exports.update = update
