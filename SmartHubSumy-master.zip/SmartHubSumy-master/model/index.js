const mongoose = require('mongoose')
const Schema = mongoose.Schema

const userSchema = new Schema({
  chat_id: String,
  username: String,
  admin: Boolean,
  meta: {
    name: String,
    age: Number,
    num_phone: String,
    mail: String,
    organisation: String,
    position: String
  },
  lang: String,
  is_bot: Boolean,
  stage: String,
  created_at: Date,
  updated_at: Date
})

const postSchema = new Schema({
  name: String,
  img: String,
  caption: String,
  tag: String
})

userSchema.pre('save', function(next) {

  let currentDate = new Date()

  this.updated_at = currentDate

  if (!this.created_at) this.created_at = currentDate

  next()

})

postSchema.pre('save', function(next) {

  let currentDate = new Date()

  this.updated_at = currentDate

  if (!this.created_at) this.created_at = currentDate

  next()

})

var User = mongoose.model('User', userSchema)
var Post = mongoose.model('Post', postSchema)

module.exports.User = User;
module.exports.Post = Post;
