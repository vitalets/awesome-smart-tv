const mongoose = require('mongoose')
const collection = 'SmartHubSumyBot'

const model = require('../model')
const Post = model.Post

mongoose.connect('mongodb://localhost/' + collection, {
  useMongoClient: true
})

mongoose.Promise = global.Promise

create = (msg) => {

  Post.create({
    name: null,
    img: null,
    caption: null,
    tag: null
  })

}

show = (callback) => {

  Post.find({}, function(err, posts) {

    for(const post of posts) callback(post)

  })

}

module.exports.create = create
module.exports.show = show
// module.export.delete = delete
