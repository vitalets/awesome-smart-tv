const json2xls = require('json2xls')

const mongoose = require('mongoose')
const collection = 'SmartHubSumyBot'

const model = require('../model')
const User = model.User

const fs = require('fs')

mongoose.connect('mongodb://localhost/' + collection, {
  useMongoClient: true
})

mongoose.Promise = global.Promise

module.exports = report = (callback) => {

  User.find({}, function(err, json) {

    var dir = './report/',
        file = 'data.xlsx'
      format = [],
      i = 1

    for (var key in json) {

      let meta = json[key].meta

      format[key] = {
        '№': i,
        'ФИО': meta.name,
        'Возраст': meta.age,
        'Номер': meta.num_phone,
        'Email': meta.mail,
        'Организация': meta.organisation,
        'Должность': meta.position
      }

      i++

    }

    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir)
    }

    var path = dir + file

    fs.writeFileSync(path, json2xls(format), 'binary')
    callback(path)
    fs.unlinkSync(path)

  })

}
