const Local = require('../local')

inline_btn = (bot, type) => {

  btn = (setting) => {

    let btn = []

    for (var key in setting) {

      btn.push(bot.inlineButton(setting[key].name, {
        callback: setting[key].cQ
      }))

    }

    return bot.inlineKeyboard([btn])

  }

  if (type == 'member') {

    return btn({
      1: { name: 'Прийду', cQ: 'Member' }
    })

  }

  if (type == 'reg') {

    return btn({
      1: { name: 'Ні', cQ: 'RefUser' },
      2: { name: 'Вперед', cQ: 'NewUser' }
    })

  }

  if (type == 'workPost') {

    return btn({
      1: { name: 'Создать', cQ: 'AddPost' },
      2: { name: 'Удалить', cQ: 'DelPost' }
    })

  }

}

module.exports.inline_btn = inline_btn
