## Welcome to SmartHubBot

This telegram-bot was written by two students from SumDU, for a nonprofit organization, our friends, from [SmartHub](http://sumy.tilda.ws/).

A SmartHub is 100 square meters of open space in the city center of Sumy, where events are regularly held to develop the city and its inhabitants. Social projects, civic initiatives and many other meetings take place here!

![Image of SmartHub](https://goo.gl/rYswpa).

### Quick start in development assistance

* Click `Watch`
* Click `Start`
* Copy the repository to a personal computer
* `But first make friends with` [@Helsis](https://github.com/HELSIS666)
* Well, you're set. Go into the section `issues`, and solve them as never before.

### Psss Back-endman 

If you forgot something -- go to bed

### Support or Contact

For all questions and problems, please contact [contact support](https://github.com/contact) and we’ll help you sort it out.
