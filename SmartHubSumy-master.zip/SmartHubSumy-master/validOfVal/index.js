module.exports = regex = (data, arg) => {

  var regex = {
    'name': /([\u0400-\u052F\u2DE0-\u2DFF\uA640-\uA69F']+(-[\u0400-\u052F\u2DE0-\u2DFF\uA640-\uA69F']+)? [\u0400-\u052F\u2DE0-\u2DFF\uA640-\uA69F']+( [\u0400-\u052F\u2DE0-\u2DFF\uA640-\uA69F']+)?)/,
    'age': /^([1][5-9]|[2-3][0-9])$/,
    'num_phone': /((\+38)[\- ]?)?(\(?\d{3}\)?[\- ]?)?[\d\- ]{7,10}/,
    'email': /(\S+)@([a-z0-9-]+)(\.)([a-z]{2,4})(\.?)([a-z]{0,4})+/
  }

  return data['text'].match(regex[arg])

}
